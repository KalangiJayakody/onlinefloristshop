package com.onlinefloristshop.backend_webshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendWebshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendWebshopApplication.class, args);
	}

}
